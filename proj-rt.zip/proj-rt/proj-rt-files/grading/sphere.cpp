#include "sphere.h"
#include "ray.h"

// Determine if the ray intersects with the sphere
Hit Sphere::Intersection(const Ray& ray, int part) const
{
	
    Hit obj;
    
    vec3 end = ray.endpoint;
    vec3 direct = ray.direction;
    double a = dot(direct,direct);
    double b = 2 * dot(end - center, direct);
    double c = dot(end - center, end - center) - radius * radius;
    
    double determinant = b * b - 4 * a * c;
    if ( determinant < 0.0) { obj.object = nullptr; return obj;}
    
    double t = (-b - sqrt(determinant))/ ( 2 * a);
    double t2 = (-b + sqrt(determinant))/(2 * a);

    if( t >= small_t && t >= part) {obj.dist = t; obj.object = this; return obj;}
    if(t2 >= small_t && t2 >= part) {obj.dist = t2; obj.object = this; return obj;}
   
    return {0,0,0};
}

vec3 Sphere::Normal(const vec3& point, int part) const
{
    vec3 normal;
    normal = point - center;
    normal = normal.normalized();
    return normal;
}

Box Sphere::Bounding_Box(int part) const
{
    Box box;
    TODO; // calculate bounding box
    return box;
}
