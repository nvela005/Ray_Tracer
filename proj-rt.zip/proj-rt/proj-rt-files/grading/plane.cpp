#include "plane.h"
#include "ray.h"
#include <cfloat>
#include <limits>

// Intersect with the half space defined by the plane.  The plane's normal
// points outside.  If the ray starts on the "inside" side of the plane, be sure
// to record a hit with t=0 as the first entry in hits.
Hit Plane::Intersection(const Ray& ray, int part) const
{
   
    Hit obj;
    vec3 end = ray.endpoint;
    vec3 direct = ray.direction;
    double t;
    double dots = dot(direct,normal);

    if(dots == 0.0) {
	
	obj.object = nullptr;
	return obj;
    }
    else { t = -1 * dot(end - x1, normal) / dots;}
    
    if( t >= small_t) { 
	obj.object = this;
	obj.dist = t;
	return obj;
    } 

    return {0,0,0};
}

vec3 Plane::Normal(const vec3& point, int part) const
{
    return normal;
}

// There is not a good answer for the bounding box of an infinite object.
// The safe thing to do is to return a box that contains everything.
Box Plane::Bounding_Box(int part) const
{
    Box b;
    b.hi.fill(std::numeric_limits<double>::max());
    b.lo=-b.hi;
    return b;
}
