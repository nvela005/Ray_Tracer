#include "render_world.h"
#include "flat_shader.h"
#include "object.h"
#include "light.h"
#include "ray.h"

extern bool disable_hierarchy;

Render_World::Render_World()
    :background_shader(0),ambient_intensity(0),enable_shadows(true),
    recursion_depth_limit(3)
{}

Render_World::~Render_World()
{
    delete background_shader;
    for(size_t i=0;i<objects.size();i++) delete objects[i];
    for(size_t i=0;i<lights.size();i++) delete lights[i];
}

// Find and return the Hit structure for the closest intersection.  Be careful
// to ensure that hit.dist>=small_t.
Hit Render_World::Closest_Intersection(const Ray& ray)
{
    
   double min_t = std::numeric_limits<double>::max();
   Hit closest_hit;
   Hit temp;
   closest_hit.object = nullptr;
   for(unsigned int i = 0; i < objects.size(); ++i) {
	
	 temp = objects.at(i)->Intersection(ray, objects.at(i)->number_parts);
	if(temp.dist < min_t && temp.dist >= small_t) { closest_hit = temp; min_t = temp.dist;}

   } 
    
    return closest_hit;
}

// set up the initial view ray and call
void Render_World::Render_Pixel(const ivec2& pixel_index)
{
     // set up the initial view ray here
    vec3 temp = camera.World_Position(pixel_index) - camera.position;
    Ray ray(camera.position, temp.normalized());

    if(debug_pixel) {
     
    	std::cout << ray.direction << std::endl;
    
    }

    vec3 color=Cast_Ray(ray,1);
    if(debug_pixel) { std::cout << std::endl << color << std::endl;}
    camera.Set_Pixel(pixel_index,Pixel_Color(color));
}

void Render_World::Render()
{
    if(!disable_hierarchy)
        Initialize_Hierarchy();

    for(int j=0;j<camera.number_pixels[1];j++)
        for(int i=0;i<camera.number_pixels[0];i++)
            Render_Pixel(ivec2(i,j));
}

// cast ray and return the color of the closest intersected surface point,
// or the background color if there is no object intersection
vec3 Render_World::Cast_Ray(const Ray& ray,int recursion_depth)
{
    vec3 color = {0,0,0};
    if(recursion_depth > recursion_depth_limit) { return color;}
    Hit closest_hit = Closest_Intersection(ray);
    if(closest_hit.object != nullptr) {
	vec3 intersect_point = ray.Point(closest_hit.dist);
	vec3 normal = closest_hit.object->Normal(intersect_point,closest_hit.part);

	if(debug_pixel) { std::cout << closest_hit.dist << " " << closest_hit.part << " " << intersect_point;}
	color = color + closest_hit.object->material_shader->Shade_Surface(ray, intersect_point, normal, recursion_depth);
			     
    }
    else {
	vec3 zero = {0,0,0};
	color = background_shader->Shade_Surface(ray,zero,zero, recursion_depth);

   } 
     // determine the color here
    return color;
}

void Render_World::Initialize_Hierarchy()
{
     // Fill in hierarchy.entries; there should be one entry for
    // each part of each object.

    hierarchy.Reorder_Entries();
    hierarchy.Build_Tree();
}
