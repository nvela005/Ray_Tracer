#include "light.h"
#include "phong_shader.h"
#include "ray.h"
#include "render_world.h"
#include "object.h"

vec3 Phong_Shader::
Shade_Surface(const Ray& ray,const vec3& intersection_point,
    const vec3& normal,int recursion_depth) const
{
    vec3 color = {0,0,0};
    vec3 emitted_light;
    vec3 direction_to_light;
    vec3 reflect_vec;
    double diffuse_dot = 0.0;
    double specular_dot = 0.0;
   
	vec3 p;



   for(unsigned int i = 0; i < world.lights.size(); ++i) {
	
	direction_to_light = world.lights.at(i)->position - intersection_point;
	Ray shadow_ray(intersection_point,direction_to_light.normalized());

	Hit closest_hit;
	closest_hit.object = nullptr;
	if(world.enable_shadows) { 
		
		closest_hit = world.Closest_Intersection(shadow_ray);
		 p = shadow_ray.Point(closest_hit.dist) - shadow_ray.endpoint;			

	}
	if(closest_hit.object == nullptr || 
	   ( p.magnitude() -  direction_to_light.magnitude()) >= 0.2) {
	
		if(debug_pixel) { std::cout << std::endl << std::endl << p.magnitude()  << " " << direction_to_light.magnitude() << std::endl;}


		diffuse_dot = dot(direction_to_light.normalized(),normal);
		
	
		reflect_vec = -1.0 * direction_to_light.normalized() + 2 * dot(direction_to_light.normalized(), normal) * normal;
		specular_dot = dot(-1.0*ray.direction, reflect_vec);	

		if( diffuse_dot < 0 ) { diffuse_dot = 0;}
		if( specular_dot < 0 ) { specular_dot = 0;}
	 
		specular_dot = pow(specular_dot,specular_power);
		emitted_light = world.lights.at(i)->Emitted_Light(direction_to_light);

		if(debug_pixel) {

			std::cout << std::endl << emitted_light[0] * color_specular[0] * specular_dot << std::endl <<  diffuse_dot * emitted_light[0] * color_diffuse[0];


		}
		color[0] = emitted_light[0] * specular_dot * color_specular[0] + emitted_light[0] * color_diffuse[0] * diffuse_dot + color[0];
		color[1] = emitted_light[1] * specular_dot * color_specular[1] + emitted_light[1] * color_diffuse[1] * diffuse_dot + color[1];
		color[2] = emitted_light[2] * specular_dot * color_specular[2] + emitted_light[2] * color_diffuse[2] * diffuse_dot + color[2];

	}


     }
	color[0] = color[0] + world.ambient_color[0] * color_ambient[0] * world.ambient_intensity;
	color[1] = color[1] + world.ambient_color[1] * color_ambient[1] * world.ambient_intensity;
	color[2] = color[2] + world.ambient_color[2] * color_ambient[2] * world.ambient_intensity;
    
    return color;
}
